
function login(){
let u=document.getElementById("user").value
let p=document.getElementById("pass").value

if(u==="admin" && p==="admin"){
alert("Admin Login Successful")
}else{
alert("User Login Successful")
}
}
