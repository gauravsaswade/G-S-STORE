
fetch('data/products.json')
.then(r=>r.json())
.then(products=>{

const grid=document.getElementById("grid")

function show(list){
grid.innerHTML=""
list.forEach(p=>{
grid.innerHTML+=`
<div class="card">
<img src="${p.image}">
<h3>${p.name}</h3>
<p>₹${p.price}</p>
<button onclick="addCart('${p.name}',${p.price})">Add to Cart</button>
</div>`
})
}

show(products)

document.getElementById("search").oninput=e=>{
let q=e.target.value.toLowerCase()
show(products.filter(p=>p.name.toLowerCase().includes(q)))
}

})

function addCart(name,price){
let cart=JSON.parse(localStorage.getItem("cart")||"[]")
cart.push({name,price})
localStorage.setItem("cart",JSON.stringify(cart))
alert("Added to cart")
}
