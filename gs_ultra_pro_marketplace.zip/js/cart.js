
let cart=JSON.parse(localStorage.getItem("cart")||"[]")
let div=document.getElementById("cart")

let total=0

cart.forEach(p=>{
total+=p.price
div.innerHTML+=`<p>${p.name} - ₹${p.price}</p>`
})

div.innerHTML+=`<h2>Total: ₹${total}</h2>`
